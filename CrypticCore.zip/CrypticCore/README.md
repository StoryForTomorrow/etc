# 1v1
Player
