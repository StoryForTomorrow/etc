/**
 * 
 */
package cryptic.network.util;

/**
 * @author 598Johnn897
 *
 */
public class PluginStatistics
{

}
