/**
 * 
 */
package cryptic.network.cmdframework.cmds;

import cryptic.network.cmdframework.CommandListener;

/**
 * @author 598Johnn897
 *
 */
public class HelpCommand implements CommandListener
{

}
