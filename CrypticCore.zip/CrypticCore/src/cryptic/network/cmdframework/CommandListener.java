/**
 * 
 */
package cryptic.network.cmdframework;

/**
 * @author 598Johnn897
 *
 */
public interface CommandListener
{

}
