/**
 * 
 */
/**
 * @author 598Johnn897
 *
 */
package cryptic.network;