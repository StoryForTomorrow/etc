/**
 * 
 */
package cryptic.network;

/**
 * @author 598Johnn897
 *
 */
public class CrypticAPI
{

}
